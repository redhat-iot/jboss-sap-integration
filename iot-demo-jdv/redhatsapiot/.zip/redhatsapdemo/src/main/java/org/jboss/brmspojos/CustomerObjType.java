package org.jboss.brmspojos;

/**
 * 
 * @author kprasann
 *
 */
public enum CustomerObjType {
	
	vip,
	TEST,
	DD

}
